AgroDB is an Agricultural Information System, brainchild of Niravu, an NGO based in Calicut.
