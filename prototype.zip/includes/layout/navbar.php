  <nav class="navbar" style="position:absolute">
    <div class="container">
      <ul class="navbar-list">
        <li class="navbar-item"><a class="navbar-link" href="#">AgroDB</a></li>
      </ul>
      <ul class="navbar-list" style="float:right">
        <li class="navbar-item"><a class="navbar-link" href="#">CONTACT US</a></li>
      </ul>
    </div>
  </nav>