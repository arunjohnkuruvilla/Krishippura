  <nav class="navbar">
    <div class="container">
      <ul class="navbar-list">
        
      </ul>
      <ul class="navbar-list" style="float:right">
        <li class="navbar-item"><a class="navbar-link" href="/workspace/logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>