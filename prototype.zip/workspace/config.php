<?php 
/**
 * This file has all the configuration variables for the wiki.
 * Change them according to the host.
 */

//Variables for setting up MySQL connection
$host = "localhost";
$database_name = "prototype";
$database_user = "root";
$database_password = "";

//Varibles for article management
define("UPLOAD_DIR", "../../pdf/");
define("UPLOAD_IMAGE_DIR", "../../images/primary/");
$article_link = "../workspace/article/";

//Varibles for category management

//Varibles for user management

?>